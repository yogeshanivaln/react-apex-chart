import React, { useEffect, useState } from "react";
import Chart from "react-apexcharts";

export default ({ data }) => {
    const [options, setOptions] = useState({
        chart: {
            id: "basic-bar"
          },
          xaxis: {
            type: 'datetime',
            labels: {
                formatter: (value, timestamp) => new Date(timestamp).getHours() +':' + new Date(timestamp).getSeconds()
              }
          },
          dataLabels: {
            enabled: false,
          }
    });
    const [series, setSeries] = useState([
        {
            name: "Connection",
            data: [
                [1486684800000, '34'], 
                [1486771200000, '43'], 
                [1486857600000, '31'] , 
                [1486944000000, '43'], 
                [1487030400000, '33'], 
                [1487116800000, '52']
              ]
        }
    ]);

    useEffect(() => {
        if(data.length) {
            setSeries([
                {
                    name: 'connection',
                    data: data
                }
            ]);
        }
    }, [data]);
    return(
        <div>
            <Chart
                options={options}
                series={series}
                type="area"
                width="500"
            />
        </div>
    )
}