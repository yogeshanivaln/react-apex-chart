import React, {useState, useEffect} from 'react';
import './App.css';
import ApexChart from './components/apexChart';
import data from './components/oriData.json';
import axios from 'axios';

const hostData = [
  {name: "Host1", value: 'host1'},
  {name: "Host2", value: 'host2'},
  {name: "Host3", value: 'host3'},
  {name: "Host4", value: 'host4'},
  {name: "Host5", value: 'host5'}
];

const timeFilter = [
  {name: "Last 5 minutes", value: 'Last 5 minutes'},
  {name: "Last 15 minutes", value: 'Last 15 minutes'},
  {name: "Last 30 minutes", value: 'Last 30 minutes'},
  {name: "Last 1 hours", value: 'Last 5 hours'},
  {name: "Last 3 hours", value: 'Last 3 hours'},
  {name: "Last 6 hours", value: 'Last 6 hours'},
  {name: "Last 12 hours", value: 'Last 12 hours'},
  {name: "Last 24 hours", value: 'Last 24 hours'},
  {name: "Last 2 days", value: 'Last 2 days'},
  {name: "Last 7 days", value: 'Last 7 days'},
  {name: "Custome", value: 'Custome'},
];

function App() {

  const [selectedHost, setSelecteHost] = useState("");
  const [startTime, setStartTime] = useState("2020-06-14T20:10:30.781Z");
  const [endTime, setEndTime] = useState("2020-06-14T21:11:00.781Z");

  const [localData, setLocalData] = useState([]);

  const [customeTimeFlag, setCustomeTimeFlag] = useState(false);

  const url = `http://xxxxxxx:9090/api/v1/query_range?query=mongodb_connections{host=${selectedHost}, state='current'}&start=${startTime}&end=${endTime}&step=5s`;

  const getApiData = async () => {
    const response = await axios.get(url);
    // console.log('RESPONESE', response)
    // setLocalData(response.data.data.result[0].values);
  }

  useEffect(() => {
    setLocalData(data.data.result[0].values);
    // getApiData()
  }, []);

  useEffect(() => {
    console.log('startTime', startTime);
    console.log('end', endTime);
    console.log('host', selectedHost);
    // getApiData()
  }, [startTime, endTime, selectedHost])

  const dateModifier = (scale) => {
    const finalEndTime = new Date().toISOString();
    const d = new Date();
    const finalStartTime = new Date(d.setMinutes(d.getMinutes() - scale)).toISOString();
    setStartTime(finalStartTime);
    setEndTime(finalEndTime);
  }

  const handleTimeRange = (key) => {
    if(key === 'Custome') {
      setCustomeTimeFlag(true);
    } else {
      setCustomeTimeFlag(false);
      switch(key) {
        case 'Last 5 minutes': dateModifier(5); break;
        case 'Last 15 minutes': dateModifier(15);break;
        case 'Last 30 minutes': dateModifier(30);break;
        case 'Last 5 hours': dateModifier(300);break;
        case 'Last 3 hours': dateModifier(180);break;
        case 'Last 6 hours': dateModifier(360);break;
        case 'Last 12 hours': dateModifier(720);break;
        case 'Last 24 hours': dateModifier(1440);break;
        case 'Last 2 days': dateModifier(2880);break;
        case 'Last 7 days': dateModifier(10080);break;
      }
    }
  }

  return (
    <div className="App">

      <div className="conatainer">
        <div>
        <label>Select Hostname</label>
          <select className="form-control" onChange={(e) => setSelecteHost(e.target.value)}>
            {
              hostData.map(e => <option value={e.value}>{e.name}</option>)
            }
          </select>
        </div>
        <div>
          <div className="form-group">
            <label>Relative time range</label>
            {customeTimeFlag && <div><input type="date" /> <input type="date" /></div>}
            <select className="form-control" onChange={(e) => handleTimeRange(e.target.value)}>
              {
                timeFilter.map(e => <option value={e.value}>{e.name}</option>)
              }
            </select>
          </div>
        </div>
      </div>
      
      <div style={{display: 'flex'}}>
          <ApexChart data={localData} />
          <ApexChart data={localData} />
          <ApexChart data={localData} />
      </div>

    </div>
  );
}

export default App;
